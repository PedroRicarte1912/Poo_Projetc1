/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package projeto1_poo_bkp_3f;
/**
 *
 * @author Pedro Ricarte Gisler
 * @author Kaio Silva Castilho
 * @author Bruno Olimpio Garcia Lorca
 */
import java.util.Scanner;
public class Projeto1_POO_BKP_3F {
    public static void main(String[] args) {
        /**
         *CRIAÇÃO VETORES E MATRIZES
         */
        String[] NomeHospede= new String[200];
        String[] StatusQuarto=new String[100];
        int[] QuantidadeReservas=new int[100];
        int[][] frigobar=new int [100][5];
        
        
        System.out.println("Bem-Vindo ao Projeto 1 de POO 3F!!!!!!");
        System.out.println("======================================");
        Scanner resposta = new Scanner(System.in);
        System.out.println("Selecione: 1-Resevar Quarto  2-Cancelar Reserva  3-Listar Reservas  4-Consultar Hóspede  5-Editar Hóspede  6-Registrar Frigobar  7-Check-OUT");
        int resp = resposta.nextInt();
        while(resp<1 || resp>7){
            System.out.println("SELECIONE DENTRE AS OPÇÕES!");
            System.out.println("Selecione: 1-Resevar Quarto  2-Cancelar Reserva  3-Listar Reservas  4-Consultar Hóspede  5-Editar Hóspede  6-Registrar Frigobar  7-Check-OUT");
            int resp2= resposta.nextInt();
            resp=resp2;
        }
        switch(resp){
            case 1:
                System.out.println("==========Inserir Reserva de Quarto==========");
                Scanner Nome = new Scanner(System.in);
                Scanner NumeroQuarto= new Scanner(System.in);
                System.out.println("Insira o nome do hóspede:");
                String NomeH= Nome.nextLine();
                System.out.println("Insira o numero do quarto do hóspede:");
                int NumeroQ = NumeroQuarto.nextInt();
                if(NumeroQ<1 || NumeroQ>100){
                    System.out.println("Insira um número de quarto válido ( de 1 a 100):");
                    NumeroQ = NumeroQuarto.nextInt();
                }
                int i =0;
                for (int x =0;x<=100;x=x+1){
                   if(i==0){
                   if(NomeHospede[x]==""){
                        NomeHospede[x]=NomeH;    
                    }
                    if(StatusQuarto[x]=="ocupado"){
                        System.out.println("O quarto: "+x+" está ocupado!");
                    } else if(StatusQuarto[x]==""){
                        StatusQuarto[x]="ocupado";
                        System.out.println("Reserva de :"+NomeHospede[x]+" foi realizada com suceso! Reserva número:"+x);
                        QuantidadeReservas[x]=x;
                    }
                   }
                   i=1;
                 }
                break;
            case 2:
                System.out.println("==========Cancelas Reserva de Quarto==========");
                Scanner NR = new Scanner(System.in);
                System.out.println("Insira o número da reserva:");
                int NR1= NR.nextInt();
                int numeroR=0;
                for(int x=0;x<=100;x=x+1){
                    if(QuantidadeReservas[x]==NR1){
                        numeroR=x;
                    }
                }
                NomeHospede[numeroR]="";
                StatusQuarto[numeroR]="";
                
                break;
            case 3:
                
    }
  }
    
}
